import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, BookOpen, Users, TrendingUp, 
  Clock, Target, Award, ChevronRight 
} from "lucide-react";

const Dashboard = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Brain className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold bg-gradient-hero bg-clip-text text-transparent">
              LearnConnect
            </span>
          </Link>
          <div className="flex items-center gap-4">
            <Link to="/community">
              <Button variant="ghost">Community</Button>
            </Link>
            <Link to="/analytics">
              <Button variant="ghost">Analytics</Button>
            </Link>
            <Button variant="outline">Profile</Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Welcome back, Learner! 👋</h1>
          <p className="text-muted-foreground">Continue your learning journey</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="p-6 bg-gradient-card border-border/50">
            <div className="flex items-center justify-between mb-2">
              <Target className="h-5 w-5 text-primary" />
              <Badge variant="secondary">+12%</Badge>
            </div>
            <p className="text-2xl font-bold">24</p>
            <p className="text-sm text-muted-foreground">Lessons Completed</p>
          </Card>

          <Card className="p-6 bg-gradient-card border-border/50">
            <div className="flex items-center justify-between mb-2">
              <Clock className="h-5 w-5 text-secondary" />
              <Badge variant="secondary">This week</Badge>
            </div>
            <p className="text-2xl font-bold">8.5h</p>
            <p className="text-sm text-muted-foreground">Learning Time</p>
          </Card>

          <Card className="p-6 bg-gradient-card border-border/50">
            <div className="flex items-center justify-between mb-2">
              <Award className="h-5 w-5 text-accent" />
              <Badge variant="secondary">+2 new</Badge>
            </div>
            <p className="text-2xl font-bold">15</p>
            <p className="text-sm text-muted-foreground">Achievements</p>
          </Card>

          <Card className="p-6 bg-gradient-card border-border/50">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <Badge variant="secondary">Top 10%</Badge>
            </div>
            <p className="text-2xl font-bold">89%</p>
            <p className="text-sm text-muted-foreground">Success Rate</p>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Continue Learning */}
            <Card className="p-6 bg-gradient-card border-border/50">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">Continue Learning</h2>
                <Link to="/learn">
                  <Button variant="ghost" size="sm">View All <ChevronRight className="h-4 w-4 ml-1" /></Button>
                </Link>
              </div>
              <div className="space-y-4">
                <div className="p-4 rounded-lg border border-border bg-background/50 hover:bg-background transition-colors cursor-pointer">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold mb-1">Mathematics: Algebra Basics</h3>
                      <p className="text-sm text-muted-foreground">Chapter 3: Linear Equations</p>
                    </div>
                    <Badge className="bg-accent text-accent-foreground">75% Complete</Badge>
                  </div>
                  <Progress value={75} className="mb-2" />
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">15 min remaining</span>
                    <Link to="/learn">
                      <Button size="sm" className="bg-gradient-primary">Continue</Button>
                    </Link>
                  </div>
                </div>

                <div className="p-4 rounded-lg border border-border bg-background/50 hover:bg-background transition-colors cursor-pointer">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold mb-1">Science: Physics Fundamentals</h3>
                      <p className="text-sm text-muted-foreground">Module 2: Motion and Forces</p>
                    </div>
                    <Badge className="bg-secondary text-secondary-foreground">45% Complete</Badge>
                  </div>
                  <Progress value={45} className="mb-2" />
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">30 min remaining</span>
                    <Link to="/learn">
                      <Button size="sm" variant="outline">Resume</Button>
                    </Link>
                  </div>
                </div>
              </div>
            </Card>

            {/* Recommended Courses */}
            <Card className="p-6 bg-gradient-card border-border/50">
              <h2 className="text-xl font-semibold mb-4">Recommended for You</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg border border-border bg-background/50 hover:bg-background transition-colors cursor-pointer">
                  <div className="h-32 rounded-md bg-gradient-primary mb-3 flex items-center justify-center">
                    <BookOpen className="h-12 w-12 text-primary-foreground" />
                  </div>
                  <h3 className="font-semibold mb-1">Advanced Programming</h3>
                  <p className="text-sm text-muted-foreground mb-3">Build complex applications</p>
                  <Button size="sm" variant="outline" className="w-full">Start Course</Button>
                </div>

                <div className="p-4 rounded-lg border border-border bg-background/50 hover:bg-background transition-colors cursor-pointer">
                  <div className="h-32 rounded-md bg-gradient-secondary mb-3 flex items-center justify-center">
                    <Brain className="h-12 w-12 text-secondary-foreground" />
                  </div>
                  <h3 className="font-semibold mb-1">Critical Thinking</h3>
                  <p className="text-sm text-muted-foreground mb-3">Enhance problem-solving skills</p>
                  <Button size="sm" variant="outline" className="w-full">Start Course</Button>
                </div>
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Daily Challenge */}
            <Card className="p-6 bg-gradient-accent border-accent/20">
              <div className="flex items-center gap-2 mb-3">
                <Award className="h-5 w-5 text-accent-foreground" />
                <h3 className="font-semibold text-accent-foreground">Daily Challenge</h3>
              </div>
              <p className="text-sm text-accent-foreground/90 mb-4">
                Complete today's quiz to earn bonus points!
              </p>
              <Link to="/learn">
                <Button className="w-full bg-accent-foreground text-accent hover:opacity-90">
                  Take Challenge
                </Button>
              </Link>
            </Card>

            {/* Learning Streak */}
            <Card className="p-6 bg-gradient-card border-border/50">
              <h3 className="font-semibold mb-4">Learning Streak 🔥</h3>
              <div className="text-center mb-4">
                <p className="text-4xl font-bold text-secondary">7</p>
                <p className="text-sm text-muted-foreground">Days in a row</p>
              </div>
              <div className="flex justify-between text-xs">
                <div className="text-center">
                  <div className="h-8 w-8 rounded-full bg-accent/20 flex items-center justify-center mb-1">✓</div>
                  <p className="text-muted-foreground">Mon</p>
                </div>
                <div className="text-center">
                  <div className="h-8 w-8 rounded-full bg-accent/20 flex items-center justify-center mb-1">✓</div>
                  <p className="text-muted-foreground">Tue</p>
                </div>
                <div className="text-center">
                  <div className="h-8 w-8 rounded-full bg-accent/20 flex items-center justify-center mb-1">✓</div>
                  <p className="text-muted-foreground">Wed</p>
                </div>
                <div className="text-center">
                  <div className="h-8 w-8 rounded-full bg-accent/20 flex items-center justify-center mb-1">✓</div>
                  <p className="text-muted-foreground">Thu</p>
                </div>
                <div className="text-center">
                  <div className="h-8 w-8 rounded-full bg-accent/20 flex items-center justify-center mb-1">✓</div>
                  <p className="text-muted-foreground">Fri</p>
                </div>
                <div className="text-center">
                  <div className="h-8 w-8 rounded-full bg-accent/20 flex items-center justify-center mb-1">✓</div>
                  <p className="text-muted-foreground">Sat</p>
                </div>
                <div className="text-center">
                  <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center mb-1 text-primary-foreground font-bold">!</div>
                  <p className="text-muted-foreground">Sun</p>
                </div>
              </div>
            </Card>

            {/* Community Activity */}
            <Card className="p-6 bg-gradient-card border-border/50">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Community</h3>
                <Link to="/community">
                  <Button variant="ghost" size="sm">View All</Button>
                </Link>
              </div>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                    <Users className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Study Group: Math</p>
                    <p className="text-xs text-muted-foreground">5 active members</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-secondary/20 flex items-center justify-center">
                    <Users className="h-4 w-4 text-secondary" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Discussion: Physics</p>
                    <p className="text-xs text-muted-foreground">12 new messages</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
