import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Brain, TrendingUp, Target, Award, Calendar, Clock } from "lucide-react";

const Analytics = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Brain className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold bg-gradient-hero bg-clip-text text-transparent">
              LearnConnect
            </span>
          </Link>
          <div className="flex items-center gap-4">
            <Link to="/dashboard">
              <Button variant="ghost">Dashboard</Button>
            </Link>
            <Link to="/community">
              <Button variant="ghost">Community</Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Learning Analytics</h1>
          <p className="text-muted-foreground">Track your progress and insights powered by AI</p>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="p-6 bg-gradient-card border-border/50">
            <div className="flex items-center justify-between mb-2">
              <Target className="h-8 w-8 text-primary" />
              <Badge className="bg-accent text-accent-foreground">↑ 15%</Badge>
            </div>
            <p className="text-3xl font-bold mb-1">89%</p>
            <p className="text-sm text-muted-foreground">Overall Performance</p>
          </Card>

          <Card className="p-6 bg-gradient-card border-border/50">
            <div className="flex items-center justify-between mb-2">
              <Clock className="h-8 w-8 text-secondary" />
              <Badge className="bg-primary text-primary-foreground">This Month</Badge>
            </div>
            <p className="text-3xl font-bold mb-1">32.5h</p>
            <p className="text-sm text-muted-foreground">Total Learning Time</p>
          </Card>

          <Card className="p-6 bg-gradient-card border-border/50">
            <div className="flex items-center justify-between mb-2">
              <Award className="h-8 w-8 text-accent" />
              <Badge className="bg-secondary text-secondary-foreground">+5 New</Badge>
            </div>
            <p className="text-3xl font-bold mb-1">24</p>
            <p className="text-sm text-muted-foreground">Achievements Earned</p>
          </Card>

          <Card className="p-6 bg-gradient-card border-border/50">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="h-8 w-8 text-primary" />
              <Badge className="bg-accent text-accent-foreground">Top 5%</Badge>
            </div>
            <p className="text-3xl font-bold mb-1">2,450</p>
            <p className="text-sm text-muted-foreground">Points Earned</p>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Subject Progress */}
            <Card className="p-6 bg-gradient-card border-border/50">
              <h2 className="text-xl font-semibold mb-6">Subject Mastery</h2>
              <div className="space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">Mathematics</span>
                      <Badge variant="secondary">Advanced</Badge>
                    </div>
                    <span className="text-sm font-medium">85%</span>
                  </div>
                  <Progress value={85} className="h-3" />
                  <p className="text-sm text-muted-foreground mt-1">12 lessons completed • 3 in progress</p>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">Physics</span>
                      <Badge variant="secondary">Intermediate</Badge>
                    </div>
                    <span className="text-sm font-medium">68%</span>
                  </div>
                  <Progress value={68} className="h-3" />
                  <p className="text-sm text-muted-foreground mt-1">8 lessons completed • 5 in progress</p>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">Programming</span>
                      <Badge variant="secondary">Beginner</Badge>
                    </div>
                    <span className="text-sm font-medium">42%</span>
                  </div>
                  <Progress value={42} className="h-3" />
                  <p className="text-sm text-muted-foreground mt-1">5 lessons completed • 2 in progress</p>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">Chemistry</span>
                      <Badge variant="secondary">Intermediate</Badge>
                    </div>
                    <span className="text-sm font-medium">72%</span>
                  </div>
                  <Progress value={72} className="h-3" />
                  <p className="text-sm text-muted-foreground mt-1">9 lessons completed • 4 in progress</p>
                </div>
              </div>
            </Card>

            {/* Learning Patterns */}
            <Card className="p-6 bg-gradient-card border-border/50">
              <h2 className="text-xl font-semibold mb-4">AI Insights</h2>
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <div className="flex items-start gap-3">
                    <Brain className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <h3 className="font-semibold mb-1">Peak Learning Time</h3>
                      <p className="text-sm text-muted-foreground">
                        You perform best during evening hours (6-9 PM). Consider scheduling challenging topics during this time.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
                  <div className="flex items-start gap-3">
                    <TrendingUp className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                    <div>
                      <h3 className="font-semibold mb-1">Improvement Trend</h3>
                      <p className="text-sm text-muted-foreground">
                        Your accuracy has improved by 15% this month. Keep up the great work!
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-secondary/5 border border-secondary/20">
                  <div className="flex items-start gap-3">
                    <Target className="h-5 w-5 text-secondary mt-1 flex-shrink-0" />
                    <div>
                      <h3 className="font-semibold mb-1">Focus Areas</h3>
                      <p className="text-sm text-muted-foreground">
                        Physics concepts need more practice. Recommended: 2-3 review sessions this week.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Activity Calendar */}
            <Card className="p-6 bg-gradient-card border-border/50">
              <div className="flex items-center gap-2 mb-4">
                <Calendar className="h-5 w-5 text-primary" />
                <h3 className="font-semibold">Activity Heatmap</h3>
              </div>
              <div className="grid grid-cols-7 gap-1">
                {Array.from({ length: 35 }).map((_, i) => {
                  const intensity = Math.random();
                  return (
                    <div
                      key={i}
                      className={`aspect-square rounded-sm ${
                        intensity > 0.7
                          ? "bg-accent"
                          : intensity > 0.4
                          ? "bg-accent/60"
                          : intensity > 0.2
                          ? "bg-accent/30"
                          : "bg-muted"
                      }`}
                      title={`Day ${i + 1}`}
                    />
                  );
                })}
              </div>
              <div className="flex items-center justify-between mt-3 text-xs text-muted-foreground">
                <span>Less</span>
                <span>More</span>
              </div>
            </Card>

            {/* Recent Achievements */}
            <Card className="p-6 bg-gradient-card border-border/50">
              <h3 className="font-semibold mb-4">Recent Achievements</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-2 rounded-lg bg-primary/5">
                  <div className="h-10 w-10 rounded-full bg-gradient-primary flex items-center justify-center text-xl">
                    🏆
                  </div>
                  <div>
                    <p className="font-medium text-sm">Week Warrior</p>
                    <p className="text-xs text-muted-foreground">7-day streak</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-2 rounded-lg bg-accent/5">
                  <div className="h-10 w-10 rounded-full bg-gradient-accent flex items-center justify-center text-xl">
                    ⭐
                  </div>
                  <div>
                    <p className="font-medium text-sm">Perfect Score</p>
                    <p className="text-xs text-muted-foreground">Math assessment</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-2 rounded-lg bg-secondary/5">
                  <div className="h-10 w-10 rounded-full bg-gradient-secondary flex items-center justify-center text-xl">
                    📚
                  </div>
                  <div>
                    <p className="font-medium text-sm">Knowledge Seeker</p>
                    <p className="text-xs text-muted-foreground">25 lessons done</p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Recommendations */}
            <Card className="p-6 bg-primary/5 border-primary/20">
              <h3 className="font-semibold mb-2">AI Recommendations</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Based on your learning patterns:
              </p>
              <ul className="text-sm space-y-2 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>Review Physics Module 2 tomorrow</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>Try advanced Math challenges</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>Join Chemistry study group</span>
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
