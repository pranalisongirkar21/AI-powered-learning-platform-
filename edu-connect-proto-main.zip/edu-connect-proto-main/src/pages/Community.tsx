import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Brain, Users, MessageCircle, ThumbsUp, Share2 } from "lucide-react";

const Community = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Brain className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold bg-gradient-hero bg-clip-text text-transparent">
              LearnConnect
            </span>
          </Link>
          <div className="flex items-center gap-4">
            <Link to="/dashboard">
              <Button variant="ghost">Dashboard</Button>
            </Link>
            <Link to="/learn">
              <Button variant="default" className="bg-gradient-primary">Start Learning</Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Community Hub</h1>
          <p className="text-muted-foreground">Connect with peers, share knowledge, and learn together</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Study Groups */}
            <Card className="p-6 bg-gradient-card border-border/50">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Active Study Groups
                </h2>
                <Button variant="outline" size="sm">Create Group</Button>
              </div>
              
              <div className="space-y-4">
                <div className="p-4 rounded-lg border border-border bg-background/50 hover:bg-background transition-colors cursor-pointer">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold mb-1">Mathematics Study Circle</h3>
                      <p className="text-sm text-muted-foreground mb-2">
                        Collaborative problem-solving for algebra and calculus
                      </p>
                      <div className="flex gap-2">
                        <Badge variant="secondary">Math</Badge>
                        <Badge variant="secondary">25 Members</Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MessageCircle className="h-4 w-4" />
                      45 discussions
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      8 active now
                    </span>
                  </div>
                </div>

                <div className="p-4 rounded-lg border border-border bg-background/50 hover:bg-background transition-colors cursor-pointer">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold mb-1">Science Enthusiasts</h3>
                      <p className="text-sm text-muted-foreground mb-2">
                        Exploring physics, chemistry, and biology together
                      </p>
                      <div className="flex gap-2">
                        <Badge variant="secondary">Science</Badge>
                        <Badge variant="secondary">32 Members</Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MessageCircle className="h-4 w-4" />
                      28 discussions
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      5 active now
                    </span>
                  </div>
                </div>
              </div>
            </Card>

            {/* Community Posts */}
            <Card className="p-6 bg-gradient-card border-border/50">
              <h2 className="text-xl font-semibold mb-4">Recent Discussions</h2>
              
              <div className="space-y-4">
                <div className="p-4 rounded-lg border border-border bg-background/50">
                  <div className="flex items-start gap-3 mb-3">
                    <Avatar>
                      <AvatarFallback className="bg-primary text-primary-foreground">AK</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold">Arjun Kumar</span>
                        <Badge variant="secondary" className="text-xs">Mentor</Badge>
                        <span className="text-sm text-muted-foreground">2 hours ago</span>
                      </div>
                      <p className="text-sm mb-2">
                        Here's a helpful tip for solving quadratic equations: Always check if you can factor before using the formula! 
                        It often saves time. 📚
                      </p>
                      <div className="flex gap-4 text-sm text-muted-foreground">
                        <button className="flex items-center gap-1 hover:text-primary transition-colors">
                          <ThumbsUp className="h-4 w-4" />
                          <span>24</span>
                        </button>
                        <button className="flex items-center gap-1 hover:text-primary transition-colors">
                          <MessageCircle className="h-4 w-4" />
                          <span>8 replies</span>
                        </button>
                        <button className="flex items-center gap-1 hover:text-primary transition-colors">
                          <Share2 className="h-4 w-4" />
                          <span>Share</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-lg border border-border bg-background/50">
                  <div className="flex items-start gap-3 mb-3">
                    <Avatar>
                      <AvatarFallback className="bg-secondary text-secondary-foreground">PS</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold">Priya Sharma</span>
                        <span className="text-sm text-muted-foreground">5 hours ago</span>
                      </div>
                      <p className="text-sm mb-2">
                        Can someone explain the concept of momentum in simple terms? Having trouble understanding it.
                      </p>
                      <div className="flex gap-4 text-sm text-muted-foreground">
                        <button className="flex items-center gap-1 hover:text-primary transition-colors">
                          <ThumbsUp className="h-4 w-4" />
                          <span>12</span>
                        </button>
                        <button className="flex items-center gap-1 hover:text-primary transition-colors">
                          <MessageCircle className="h-4 w-4" />
                          <span>15 replies</span>
                        </button>
                        <button className="flex items-center gap-1 hover:text-primary transition-colors">
                          <Share2 className="h-4 w-4" />
                          <span>Share</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Top Contributors */}
            <Card className="p-6 bg-gradient-card border-border/50">
              <h3 className="font-semibold mb-4">Top Contributors</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback className="bg-primary text-primary-foreground">RJ</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="font-medium text-sm">Raj Patel</p>
                    <p className="text-xs text-muted-foreground">152 helpful answers</p>
                  </div>
                  <Badge className="bg-gradient-primary">🏆</Badge>
                </div>
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback className="bg-accent text-accent-foreground">SK</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="font-medium text-sm">Sneha Kapoor</p>
                    <p className="text-xs text-muted-foreground">128 helpful answers</p>
                  </div>
                  <Badge className="bg-gradient-secondary">⭐</Badge>
                </div>
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback className="bg-secondary text-secondary-foreground">VM</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="font-medium text-sm">Vikram Mehta</p>
                    <p className="text-xs text-muted-foreground">95 helpful answers</p>
                  </div>
                  <Badge className="bg-gradient-accent">✨</Badge>
                </div>
              </div>
            </Card>

            {/* Trending Topics */}
            <Card className="p-6 bg-gradient-card border-border/50">
              <h3 className="font-semibold mb-4">Trending Topics</h3>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary" className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors">
                  #Algebra
                </Badge>
                <Badge variant="secondary" className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors">
                  #Physics
                </Badge>
                <Badge variant="secondary" className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors">
                  #Programming
                </Badge>
                <Badge variant="secondary" className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors">
                  #StudyTips
                </Badge>
                <Badge variant="secondary" className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors">
                  #Chemistry
                </Badge>
                <Badge variant="secondary" className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors">
                  #ExamPrep
                </Badge>
              </div>
            </Card>

            {/* Community Guidelines */}
            <Card className="p-6 bg-primary/5 border-primary/20">
              <h3 className="font-semibold mb-2">Community Guidelines</h3>
              <p className="text-sm text-muted-foreground">
                Be respectful, helpful, and inclusive. Share knowledge freely and support fellow learners.
              </p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Community;
