import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Brain, ArrowRight, CheckCircle2, XCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const questions = [
  {
    id: 1,
    question: "What is 15 + 27?",
    options: ["42", "41", "43", "40"],
    correct: 0,
    difficulty: "easy"
  },
  {
    id: 2,
    question: "Solve: 3x + 5 = 14",
    options: ["x = 3", "x = 4", "x = 5", "x = 2"],
    correct: 0,
    difficulty: "medium"
  },
  {
    id: 3,
    question: "What is the slope of the line y = 2x + 3?",
    options: ["3", "2", "1", "0"],
    correct: 1,
    difficulty: "medium"
  }
];

const Learn = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answeredQuestions, setAnsweredQuestions] = useState(0);
  const { toast } = useToast();

  const handleAnswer = (optionIndex: number) => {
    if (showResult) return;
    
    setSelectedAnswer(optionIndex);
    setShowResult(true);
    setAnsweredQuestions(prev => prev + 1);

    const isCorrect = optionIndex === questions[currentQuestion].correct;
    
    if (isCorrect) {
      setScore(prev => prev + 1);
      toast({
        title: "Correct! 🎉",
        description: "Great job! Moving to the next question...",
      });
    } else {
      toast({
        title: "Not quite right",
        description: "Let's try another question to help you learn.",
        variant: "destructive",
      });
    }
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    }
  };

  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const accuracy = answeredQuestions > 0 ? (score / answeredQuestions) * 100 : 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Brain className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold bg-gradient-hero bg-clip-text text-transparent">
              LearnConnect
            </span>
          </Link>
          <Link to="/dashboard">
            <Button variant="ghost">Back to Dashboard</Button>
          </Link>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold mb-2">Adaptive Math Assessment</h1>
              <p className="text-muted-foreground">AI-powered difficulty adjustment based on your performance</p>
            </div>
            <Badge className="bg-gradient-primary text-lg px-4 py-2">
              Score: {score}/{answeredQuestions}
            </Badge>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Progress</span>
              <span>Question {currentQuestion + 1} of {questions.length}</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="p-4 bg-gradient-card border-border/50">
            <p className="text-sm text-muted-foreground mb-1">Current Difficulty</p>
            <p className="text-2xl font-bold capitalize text-primary">
              {questions[currentQuestion].difficulty}
            </p>
          </Card>
          <Card className="p-4 bg-gradient-card border-border/50">
            <p className="text-sm text-muted-foreground mb-1">Accuracy</p>
            <p className="text-2xl font-bold text-accent">
              {accuracy.toFixed(0)}%
            </p>
          </Card>
          <Card className="p-4 bg-gradient-card border-border/50">
            <p className="text-sm text-muted-foreground mb-1">AI Adaptation</p>
            <p className="text-2xl font-bold text-secondary">Active</p>
          </Card>
        </div>

        {/* Question Card */}
        <Card className="p-8 bg-gradient-card border-border/50 shadow-lg">
          <div className="mb-6">
            <Badge variant="secondary" className="mb-4">
              Question {currentQuestion + 1}
            </Badge>
            <h2 className="text-2xl font-bold mb-2">
              {questions[currentQuestion].question}
            </h2>
            <p className="text-muted-foreground">Select the correct answer</p>
          </div>

          <div className="space-y-3 mb-6">
            {questions[currentQuestion].options.map((option, index) => {
              const isSelected = selectedAnswer === index;
              const isCorrect = index === questions[currentQuestion].correct;
              const showCorrect = showResult && isCorrect;
              const showWrong = showResult && isSelected && !isCorrect;

              return (
                <button
                  key={index}
                  onClick={() => handleAnswer(index)}
                  disabled={showResult}
                  className={`w-full p-4 rounded-lg border-2 text-left transition-all duration-300 ${
                    showCorrect
                      ? "border-accent bg-accent/10"
                      : showWrong
                      ? "border-destructive bg-destructive/10"
                      : isSelected
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/50 hover:bg-muted/50"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{option}</span>
                    {showCorrect && <CheckCircle2 className="h-5 w-5 text-accent" />}
                    {showWrong && <XCircle className="h-5 w-5 text-destructive" />}
                  </div>
                </button>
              );
            })}
          </div>

          {showResult && (
            <div className="flex items-center justify-between pt-6 border-t border-border">
              <div className="text-sm text-muted-foreground">
                {selectedAnswer === questions[currentQuestion].correct
                  ? "AI is maintaining current difficulty level"
                  : "AI is adjusting difficulty for better learning"}
              </div>
              {currentQuestion < questions.length - 1 ? (
                <Button onClick={nextQuestion} className="bg-gradient-primary">
                  Next Question <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              ) : (
                <Link to="/analytics">
                  <Button className="bg-gradient-accent">
                    View Results <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              )}
            </div>
          )}
        </Card>

        {/* AI Insights */}
        <Card className="mt-6 p-6 bg-primary/5 border-primary/20">
          <div className="flex items-start gap-4">
            <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
              <Brain className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold mb-2">AI Learning Assistant</h3>
              <p className="text-sm text-muted-foreground">
                The platform is analyzing your responses in real-time to provide 
                personalized content recommendations and adjust question difficulty 
                to optimize your learning experience.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Learn;
